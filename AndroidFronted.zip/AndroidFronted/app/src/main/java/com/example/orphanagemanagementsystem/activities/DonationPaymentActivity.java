package com.example.orphanagemanagementsystem.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.orphanagemanagementsystem.R;

public class DonationPaymentActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnAmount,btnDonate,btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donation_payment);
        btnAmount = findViewById(R.id.btnAmount);
        btnDonate = findViewById(R.id.btnDonate);
        btnCancel = findViewById(R.id.btnCancel);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnDonate){
            Toast.makeText(this, "THANKU FOR DONATION", Toast.LENGTH_SHORT).show();
        } else if (v.getId() == R.id.btnCancel) {
           finish();
        }
        else if (v.getId() == R.id.btnAmount) {

        }
    }
}