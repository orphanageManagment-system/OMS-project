package com.example.orphanagemanagementsystem.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.orphanagemanagementsystem.R;


public class ChildDetailsActivity extends AppCompatActivity implements View.OnClickListener {


    Button btnAdopt,btnCancel;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_details);
        btnAdopt = findViewById(R.id.btnAdopt);
        btnCancel = findViewById(R.id.btnCancel);
        btnAdopt.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnAdopt){
            startActivity(new Intent(this,RegisterAdopterActivity.class));
        } else if (v.getId() == R.id.btnCancel) {
            finish();
        }
    }
}