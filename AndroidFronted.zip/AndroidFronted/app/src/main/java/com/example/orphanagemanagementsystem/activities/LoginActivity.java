package com.example.orphanagemanagementsystem.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.orphanagemanagementsystem.R;
import com.example.orphanagemanagementsystem.entites.Crendtials;
import com.example.orphanagemanagementsystem.utils.RetrofitClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editEmail, editPassword;
    Button btnLogin;
    TextView textRegister;
    CheckBox checkboxRememberMe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.btnLogin);
        textRegister = findViewById(R.id.textRegister);
        checkboxRememberMe = findViewById(R.id.checkboxRememberMe);
        btnLogin.setOnClickListener(this);
        textRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.btnLogin){
            if(checkboxRememberMe.isChecked()){
                getSharedPreferences("user_details",MODE_PRIVATE).edit().putBoolean("login_status",true).apply();
            }

//            Toast.makeText(this, "clik login", Toast.LENGTH_SHORT).show();
            Crendtials crendtials = new Crendtials();
            crendtials.setEmail(editEmail.getText().toString());
            crendtials.setPassword(editPassword.getText().toString());
            RetrofitClient.getRetrofitClient().getApi()
                    .loginUser(crendtials).enqueue(new Callback<JsonObject>() {
                        @Override
                        public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                            if (response.body().getAsJsonObject().get("status").getAsString().equals("success")){
                                String email =response.body().getAsJsonObject().get("data").getAsJsonObject().get("email").toString();
                                String password =response.body().getAsJsonObject().get("data").getAsJsonObject().get("password").toString();
                                                // userId
                                getSharedPreferences("user_details", MODE_PRIVATE).edit()
                                        .putInt("uid", response.body().getAsJsonObject().get("data").getAsJsonObject().get("userId").getAsInt()).apply();
                                Toast.makeText(LoginActivity.this, "Login", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(LoginActivity.this, HomeActivity.class));

                                finish();
                            }
                            else if(response.body().getAsJsonObject().get("status").getAsString().equals("Error")) {
                                Toast.makeText(LoginActivity.this, "not valid", Toast.LENGTH_SHORT).show();

                            }


                        }

                        @Override
                        public void onFailure(Call<JsonObject> call, Throwable t) {
                            Toast.makeText(LoginActivity.this, "Error", Toast.LENGTH_SHORT).show();
                        }
                    });








        }
        else if (v.getId() == R.id.textRegister) {
            Toast.makeText(this, "register btn clik", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, RegisterActivity.class));
        }

    }


}