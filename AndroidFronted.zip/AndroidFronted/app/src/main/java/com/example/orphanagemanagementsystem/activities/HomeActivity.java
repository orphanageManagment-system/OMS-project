package com.example.orphanagemanagementsystem.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.orphanagemanagementsystem.R;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {


    TextView adoption, donation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        adoption = findViewById(R.id.adoption);
        donation = findViewById(R.id.donation);
        adoption.setOnClickListener(this);
        donation.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.adoption){
            Toast.makeText(this, "Adoption btn clik", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this,ChildListActivity.class));
        }
        else if(v.getId() == R.id.donation){
            Toast.makeText(this, "donation btn clik", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this,DonationActivity.class));
        }
    }
}