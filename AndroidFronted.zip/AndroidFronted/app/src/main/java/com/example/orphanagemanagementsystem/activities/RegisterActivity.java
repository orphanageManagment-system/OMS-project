package com.example.orphanagemanagementsystem.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.orphanagemanagementsystem.R;
import com.example.orphanagemanagementsystem.entites.User;
import com.example.orphanagemanagementsystem.utils.RetrofitClient;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener
{
    EditText editFirstName,editLastName,editPassword,editMobile,editEmail;
    Button btnRegister,btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        editFirstName = findViewById(R.id.editFirstName);
        editPassword = findViewById(R.id.editPassword);
        editLastName = findViewById(R.id.editLastName);
        editMobile = findViewById(R.id.editMobile);
        editEmail = findViewById(R.id.editEmail);
        btnRegister = findViewById(R.id.btnRegister);
        btnCancel = findViewById(R.id.btnCancel);
        btnRegister.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {


        if(v.getId() == R.id.btnRegister ){
            User user = new User();
           user.setFirstName(editFirstName.getText().toString());
           user.setLastName(editLastName.getText().toString());
           user.setEmail(editEmail.getText().toString());
           user.setMobile(editMobile.getText().toString());
           user.setPassword(editPassword.getText().toString());

            RetrofitClient.getRetrofitClient().getApi().registerUser(user).enqueue(new Callback<JsonObject>() {
                @Override
                public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                    String mes = response.body().getAsJsonObject().get("message").getAsString();
                    Toast.makeText(RegisterActivity.this, mes, Toast.LENGTH_SHORT).show();

                    if(response.body().getAsJsonObject().get("status").getAsString().equals("success")){

                        Toast.makeText(RegisterActivity.this, mes, Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegisterActivity.this,LoginActivity.class));

                    }
                    else {
                        Toast.makeText(RegisterActivity.this, mes, Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<JsonObject> call, Throwable t) {

                }
            });

        }

    }
}