package com.example.orphanagemanagementsystem.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.orphanagemanagementsystem.R;
import com.example.orphanagemanagementsystem.adapters.ChildAdapter;
import com.example.orphanagemanagementsystem.entites.Child;

import java.util.ArrayList;
import java.util.List;

public class ChildListActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    ChildAdapter childAdapter;
    List<Child> childList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        childList = new ArrayList<>();
        setContentView(R.layout.activity_child_list);

        recyclerView = findViewById(R.id.recyclerView);

        Child child = new Child();
        child.setName("hero");
        child.setAge("4");
        child.setBirthdate("2/4/2009");
        child.setGender("Female");
        child.setEnjoys("food");
        childList.add(child);
        childAdapter = new ChildAdapter(childList,this);

        recyclerView.setAdapter(childAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this,1));




    }
}