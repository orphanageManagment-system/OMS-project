package com.example.orphanagemanagementsystem.utils;

import com.example.orphanagemanagementsystem.entites.Crendtials;
import com.example.orphanagemanagementsystem.entites.User;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface API {
    String BASE_URL = "http://192.168.180.178:8080/";

    @POST("user/login")
    Call<JsonObject> loginUser(@Body Crendtials crendtials);

    @POST("user/registration")
    Call<JsonObject> registerUser(@Body User user);
}
