package com.example.orphanagemanagementsystem.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.orphanagemanagementsystem.R;
import com.example.orphanagemanagementsystem.activities.ChildDetailsActivity;
import com.example.orphanagemanagementsystem.entites.Child;

import java.util.List;

public class ChildAdapter extends RecyclerView.Adapter<ChildAdapter.MyViewHolder>
{


    List <Child> childList;
    Context context;

    public ChildAdapter(List<Child> childList, Context context) {
        this.childList = childList;
        this.context = context;
    }

    @NonNull
    @Override
    public ChildAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.child_list,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChildAdapter.MyViewHolder holder, int position) {

        holder.childName.setText(childList.get(position).getName());
        holder.childAge.setText(childList.get(position).getAge());
        holder.childGender.setText(childList.get(position).getGender());
    }

    @Override
    public int getItemCount() {
        return childList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView childName,childAge,childGender;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            childName = itemView.findViewById(R.id.childName);
            childGender = itemView.findViewById(R.id.childGender);
            childAge = itemView.findViewById(R.id.childAge);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            context.startActivity(new Intent(context, ChildDetailsActivity.class));
        }
    }
}
