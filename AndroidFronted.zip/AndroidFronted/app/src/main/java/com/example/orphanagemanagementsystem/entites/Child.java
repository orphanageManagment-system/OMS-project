package com.example.orphanagemanagementsystem.entites;

public class Child
{
    int childId;
    String name;
    String age;
    String gender;
    String enjoys;
    String birthdate;
    String health;

    public Child(){

    }

    public Child(int childId, String name, String age, String gender, String enjoys, String birthdate, String health) {
        this.childId = childId;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.enjoys = enjoys;
        this.birthdate = birthdate;
        this.health = health;
    }

    public int getChildId() {
        return childId;
    }

    public void setChildId(int childId) {
        this.childId = childId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEnjoys() {
        return enjoys;
    }

    public void setEnjoys(String enjoys) {
        this.enjoys = enjoys;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getHealth() {
        return health;
    }

    public void setHealth(String health) {
        this.health = health;
    }

    @Override
    public String toString() {
        return "Child{" +
                "childId=" + childId +
                ", name='" + name + '\'' +
                ", age='" + age + '\'' +
                ", gender='" + gender + '\'' +
                ", enjoys='" + enjoys + '\'' +
                ", birthdate='" + birthdate + '\'' +
                ", health='" + health + '\'' +
                '}';
    }
}
