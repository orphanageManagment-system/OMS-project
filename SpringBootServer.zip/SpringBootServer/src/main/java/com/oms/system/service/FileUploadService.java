package com.oms.system.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.oms.system.entity.Adopter;
import com.oms.system.entity.ResponseResult;
import com.oms.system.entity.User;

@Service
public class FileUploadService {

	
}
